package com.example.xmltojson.service;
import org.json.JSONObject;
import org.json.XML;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.*;

@Service
public class XmlToJsonService {
    public String convertXmlToJson(MultipartFile file, String outputPath) {
        try {
           
            String xmlContent = new String(file.getBytes());

            JSONObject jsonObject = XML.toJSONObject(xmlContent);
            String jsonContent = jsonObject.toString(4);

            File outputFile = new File(outputPath);
            try (FileWriter fileWriter = new FileWriter(outputFile)) {
                fileWriter.write(jsonContent);
            }

            return outputFile.getAbsolutePath();
        } catch (Exception e) {
            throw new RuntimeException("Error converting XML to JSON: " + e.getMessage(), e);
        }
    }
}
