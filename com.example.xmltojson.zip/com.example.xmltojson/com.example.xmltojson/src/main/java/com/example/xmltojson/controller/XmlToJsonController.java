package com.example.xmltojson.controller;
import com.example.xmltojson.service.XmlToJsonService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping("/convert")
public class XmlToJsonController {
    private final XmlToJsonService xmlToJsonService;

    public XmlToJsonController(XmlToJsonService xmlToJsonService) {
        this.xmlToJsonService = xmlToJsonService;
    }

    @PostMapping("/xml-to-json")
    public ResponseEntity<String> convertXmlToJson(@RequestParam("file") MultipartFile file,
                                                   @RequestParam("outputPath") String outputPath) {
        String jsonFilePath = xmlToJsonService.convertXmlToJson(file, outputPath);
        return ResponseEntity.ok("JSON file saved at: " + jsonFilePath);
    }
}
