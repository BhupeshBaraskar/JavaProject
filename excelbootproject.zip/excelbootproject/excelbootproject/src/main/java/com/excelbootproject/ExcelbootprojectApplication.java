package com.excelbootproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExcelbootprojectApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExcelbootprojectApplication.class, args);
				
	  System.out.println("Hello");
	}
}
