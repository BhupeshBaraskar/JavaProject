package com.fileprocessor.controller;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import com.fileprocessor.service.FileProcessingService;

import java.util.List;

@RestController
@RequestMapping("/file")
public class FileController {
    private final FileProcessingService fileProcessingService;

    public FileController(FileProcessingService fileProcessingService) {
        this.fileProcessingService = fileProcessingService;
    }

    @PostMapping("/upload")
    public ResponseEntity<List<List<String>>> uploadFile(
            @RequestParam("file") MultipartFile file,
            @RequestParam("startRow") int startRow) {
        List<List<String>> data = fileProcessingService.processFile(file, startRow);
        return ResponseEntity.ok(data);
    }
}
