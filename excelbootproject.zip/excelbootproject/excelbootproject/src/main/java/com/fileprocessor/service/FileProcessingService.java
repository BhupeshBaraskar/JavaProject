package com.fileprocessor.service;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

	import java.io.*;
	import java.util.ArrayList;
	import java.util.List;

	@Service
	public class FileProcessingService {
	    public List<List<String>> processFile(MultipartFile file, int startRow) {
	        String fileType = file.getContentType();
	        try (InputStream inputStream = file.getInputStream()) {
	            if (fileType != null && fileType.contains("csv")) {
	                return readCSV(inputStream, startRow);
	            } else if (fileType != null && fileType.contains("excel")) {
	                return readExcel(inputStream, startRow);
	            } else {
	                throw new IllegalArgumentException("Unsupported file type");
	            }
	        } catch (Exception e) {
	            throw new RuntimeException("Error processing file: " + e.getMessage(), e);
	        }
	    }

	    private List<List<String>> readCSV(InputStream inputStream, int startRow) throws IOException, CsvException {
	        List<List<String>> data = new ArrayList<>();
	        try (CSVReader reader = new CSVReader(new InputStreamReader(inputStream))) {
	            List<String[]> allRows = reader.readAll();
	            for (int i = startRow; i < allRows.size(); i++) {
	                data.add(List.of(allRows.get(i)));
	            }
	        }
	        return data;
	    }

	    private List<List<String>> readExcel(InputStream inputStream, int startRow) throws IOException {
	        List<List<String>> data = new ArrayList<>();
	        Workbook workbook = new XSSFWorkbook(inputStream);
	        Sheet sheet = workbook.getSheetAt(0);
	        for (int i = startRow; i <= sheet.getLastRowNum(); i++) {
	            Row row = sheet.getRow(i);
	            if (row != null) {
	                List<String> rowData = new ArrayList<>();
	                for (Cell cell : row) {
	                    rowData.add(cell.toString());
	                }
	                data.add(rowData);
	            }
	        }
	        workbook.close();
	        return data;
	    }
	}

